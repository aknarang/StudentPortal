﻿using StudentClient.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Web.Mvc;

namespace StudentClient.Controllers
{
    public class StudentController : Controller
    {
        public ActionResult Index()
        {
            return View();
        }

        /// <summary>
        /// Getting All Students By DistrictId or fetch all students in case of districtId as null
        /// </summary>
        /// <param name="districtId"></param>
        /// <returns></returns>
        public ActionResult GetAllStudents(int? districtId)
        {
            IEnumerable<StudentViewModel> students = null;
            using (var client = new HttpClient())
            {
                // Better place of urls are in configuration file
                client.BaseAddress = new Uri("http://localhost:4514/api/");
                var responseTask = client.GetAsync("Students/GetAllStudentsByDistrictId?districtId=" + districtId);
                responseTask.Wait();
                var result = responseTask.Result;
                if (result.IsSuccessStatusCode)
                {
                    var readTask = result.Content.ReadAsAsync<IList<StudentViewModel>>();
                    readTask.Wait();
                    students = readTask.Result;
                }
                else
                {
                    //log response status here..
                    students = Enumerable.Empty<StudentViewModel>();
                    ModelState.AddModelError(string.Empty, "Server error. Please contact administrator.");
                }
            }
            return View(students);
        }

        /// <summary>
        /// Getting All Student Services based on schoolYear
        /// </summary>
        /// <param name="schoolYear"></param>
        /// <returns></returns>
        public ActionResult GetAllStudentServices(int? schoolYear)
        {
            IEnumerable<StudentViewModel> students = null;
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri("http://localhost:4514/api/");
                var responseTask = client.GetAsync("Students/GetAllStudentServices?schoolYear=" + schoolYear + "&serviceName="+string.Empty);
                responseTask.Wait();
                var result = responseTask.Result;
                if (result.IsSuccessStatusCode)
                {
                    var readTask = result.Content.ReadAsAsync<IList<StudentViewModel>>();
                    readTask.Wait();
                    students = readTask.Result;
                }
                else
                {
                    //log response status here..
                    students = Enumerable.Empty<StudentViewModel>();
                    ModelState.AddModelError(string.Empty, "Server error. Please contact administrator.");
                }
            }
            return View(students);
        }

        /// <summary>
        /// Getting All Student Enrollments based on schoolYear
        /// </summary>
        /// <param name="schoolYear"></param>
        /// <returns></returns>
        public ActionResult GetAllStudentEnrollments(int? schoolYear)
        {
            IEnumerable<StudentViewModel> students = null;
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri("http://localhost:4514/api/");
                var responseTask = client.GetAsync("Students/GetAllStudentServices?schoolYear=" + schoolYear + "&serviceName=Enrollment");
                responseTask.Wait();
                var result = responseTask.Result;
                if (result.IsSuccessStatusCode)
                {
                    var readTask = result.Content.ReadAsAsync<IList<StudentViewModel>>();
                    readTask.Wait();
                    students = readTask.Result;
                }
                else
                {
                    //log response status here..
                    students = Enumerable.Empty<StudentViewModel>();
                    ModelState.AddModelError(string.Empty, "Server error. Please contact administrator.");
                }
            }
            return View("GetAllStudentServices", students);
        }
    }
}