﻿using System;
using System.ComponentModel.DataAnnotations;

namespace StudentService.Models
{
    public class StudentViewModel
    {
        public long StudentId { get; set; }
        public string Ssn { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        [DisplayFormat(DataFormatString = "{0:d}")]
        public Nullable<DateTime> DateOfBirth { get; set; }
        public Nullable<int> DistrictId { get; set; }
        public Nullable<int> SchoolYear { get; set; }
        [DisplayFormat(DataFormatString = "{0:d}")]
        public Nullable<DateTime> StartDate { get; set; }
        [DisplayFormat(DataFormatString = "{0:d}")]
        public Nullable<DateTime> EndDate { get; set; }
        public string ServiceName { get; set; }
    }
}