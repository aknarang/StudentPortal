﻿using StudentService.BusinessLogic;
using StudentService.Models;
using System.Collections.Generic;
using System.Web.Http;

namespace StudentService.Controllers
{
    public class StudentsController : ApiController
    {
        private StudentEntity db = new StudentEntity();
        StudentRepository repository = null;
        public IHttpActionResult GetAllStudents(int? districtId)
        {
            repository= new StudentRepository();
            List<StudentViewModel> studentVmList = new List<StudentViewModel>();
            studentVmList = repository.GetAllStudentsByDistrictId(districtId);
            if (studentVmList == null)
            {
                return NotFound();
            }
            return Ok(studentVmList);
        }

        public IHttpActionResult GetAllStudentServices(int? schoolYear, string serviceName)
        {
            repository = new StudentRepository();
            List<StudentViewModel> studentVmList = new List<StudentViewModel>();
            studentVmList = repository.GetAllStudentServices(schoolYear, serviceName);
            if (studentVmList == null)
            {
                return NotFound();
            }
            return Ok(studentVmList);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}