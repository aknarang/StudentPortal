﻿using StudentService.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StudentService.BusinessLogic
{
    public interface IStudentContract
    {
        List<StudentViewModel> GetAllStudentsByDistrictId(int? districtId);
        List<StudentViewModel> GetAllStudentServices(int? schoolYear, string serviceName);
    }
}
