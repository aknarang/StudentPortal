﻿using StudentService.Models;
using System.Collections.Generic;
using System.Linq;

namespace StudentService.BusinessLogic
{
    public class StudentRepository: IStudentContract
    {
        private StudentEntity db = new StudentEntity();

        public List<StudentViewModel> GetAllStudentsByDistrictId(int? districtId)
        {
            List<StudentViewModel> studentVmList = new List<StudentViewModel>();            

            if (districtId != null)
            {
                studentVmList = GetAllStudents().Where(x => x.DistrictId == districtId).ToList();
            }
            else
            {
                studentVmList = GetAllStudents().ToList();
            }
            return studentVmList;
        }

        public List<StudentViewModel> GetAllStudentServices(int? schoolYear, string serviceName)
        {
            List<StudentViewModel> studentVmList = new List<StudentViewModel>();
            if (schoolYear != null)
            {
                studentVmList = !string.IsNullOrWhiteSpace(serviceName) ? GetAllStudents()
                            .Where(x => x.SchoolYear == schoolYear && x.ServiceName == serviceName)
                            .ToList()
                            : GetAllStudents()
                            .Where(x => x.SchoolYear == schoolYear)
                            .ToList();
            }
            else
            {
                studentVmList = !string.IsNullOrWhiteSpace(serviceName) ? GetAllStudents()
                            .Where(x => x.ServiceName == serviceName)
                            .ToList()
                            : GetAllStudents()
                            .ToList();
            }
            return studentVmList;
        }

        private List<StudentViewModel> GetAllStudents()
        {
            List<StudentViewModel> studentVmList = new List<StudentViewModel>();
            studentVmList = db.Students
                        .Join(db.Services, st => st.Id, se => se.StudentId, (student, service) => new StudentViewModel
                        {
                            StudentId = student.Id,
                            DateOfBirth = student.DateOfBirth,
                            EndDate = service.EndDate,
                            DistrictId = student.DistrictId,
                            FirstName = student.FirstName,
                            LastName = student.LastName,
                            SchoolYear = service.SchoolYear,
                            ServiceName = service.ServiceName,
                            Ssn = student.Ssn,
                            StartDate = service.StartDate
                        })
                        .ToList();
            return studentVmList;
        }
    }
}